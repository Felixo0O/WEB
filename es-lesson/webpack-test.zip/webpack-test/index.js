const say = () => {
  console.log('hello world')
}
say()
