<template lang="html">
  <div class="list">
    <ul>
      <li v-for="item in list" :key="item.name">
        {{item.name.trim()}}-{{item.addr}}
      </li>
    </ul>
    {{priceTxt}}
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'list',
  data () {
    return {
      list: [],
      priceTxt: ''
    }
  },
  async mounted () {
    const { data: { list, price, rate } } = await axios.get('/list')
    this.$data.list = list
    this.$data.priceTxt = navigator.language === 'zh-CN' ? `￥${price * rate}` : `$${price}`
  }
}
</script>

<style lang="css" scoped>
</style>
